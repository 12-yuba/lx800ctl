# LX800 救砖 / 固件烧录工具包

> **只有屏幕已经变砖才需要看这份文档。**
> 判断标准：插上 USB 后屏幕不亮、设备管理器里**没有** `1A2C:151D`。
> 只要屏幕还能正常枚举 `1A2C:151D`，就用不到这里的东西，直接用上位机 `LX800Controller` 即可。

工具包版本：v1.0　|　适用硬件：TCOMAS LX800（480×480，主控 N32905 / W55FA93，板载 16MB SPI NOR）

---

## 1. 为什么会砖（救砖依据）

LX800 的主控是新唐 **N32905 / W55FA93**（ARM926EJ-S + 8MB DDR）。程序**不在 MCU 内部 Flash**，
而是放在板载 **16MB SPI NOR**（JEDEC ID `A1 40 18`，丝印 H25H128AE 系列）里，上电从 NOR 加载运行。

「烧录开机动画」本质上是往 NOR 偏移 **`0x400000`** 的动画库区写数据。
**只要写进去的 blob 格式有任何一处不对**（帧数编码、索引表字段、meta 校验值），
芯片上电加载动画库时就会跑飞 —— 表现为**屏幕不亮、USB 不枚举、上位机连不上**。

关键事实：**BootROM 是固化在芯片里的，擦不掉。**
只要能让芯片进 BootROM 刷机态（USB `VID_0416&PID_9396`，USB Mass Storage 类），
就一定能把固件重新烧回去。**这台设备就是这么救回来的**，下面的步骤是实机跑通过的全流程。

### 常见误判

烧错固件后芯片跑飞 → D+ 无上拉 → **D+ 实测 0V** → 看起来像"供电坏了 / USB 线断了 / 焊接失败"。
实测证伪：用万用表量 D+ 为 0V，同时 UART 打不出 `SPI Booting Success`，才定位到是固件没正确加载，
**不是硬件问题**。别急着动烙铁。

---

## 2. 所需软件

| 用途 | 软件 / 文件 | 来源 |
|---|---|---|
| SPI NOR 烧录器 | **TurboWriter V2.30.003_N329x1** | 新唐官方开源工具 [OpenNuvoton/N32905_NonOS_Tool](https://github.com/OpenNuvoton/N32905_NonOS_Tool)，**本包已带** |
| NOR 型号识别补丁 | `SPIFLASH ID.ini` 第 7 行加 `A14018　　16384` | **本包已打好补丁**，开箱即用 |
| 救砖固件 | `firmware/make_fix.bin`（589,824 B） | **本包已带** |
| （可选）串口日志 | CH340 + 板载 TX/RX/GND，COMx **115200**（不接 VCC） | 只在排查时用，正常救砖**不需要** |

---

## 3. 目录结构

```
LX800_Rescue_Tool_v1.0/
├── README_Rescue.md                          ← 本文件
├── hardware_boot_pins.jpg                    ← 强制烧录模式的短接位置实拍图
├── firmware/
│   └── make_fix.bin                          ← 救砖固件，唯一能直接烧的文件
└── TurboWriter V2.30.003_N329x1/
    ├── TurboWriter.exe                       ← 运行这个
    ├── TurboWriter.ini
    ├── TurboWriterSD.ini
    ├── SPIFLASH ID.ini                       ← 已打补丁（含 A14018 = 16384）
    ├── NAND ID.ini
    ├── musb.bin / FA93_musb.bin / FA93_musb_FullSpeed.bin
    ├── ChangeLog.txt
    └── TurboWriter Tool User Guide.pdf       ← 新唐官方使用手册
```

---

## 4. 固件文件

| 文件 | 大小 | SHA256 |
|---|---|---|
| **`firmware/make_fix.bin`** | 589,824 | `fc7ed1c4efa6eac29fd37ca9ef43f505c7a7e36fd3aab015a600e7b1fcf4b206` |

烧录时 **只选这一个文件**，不要拿官方升级器里的镜像或其它来源的固件直接烧。

> **关于序列号**：`make_fix.bin` 里确实能搜到一串 `A247392SS000000`（偏移 `0x27ED4`，紧跟在
> `load eeprom faild` 字符串后面）。这是**官方固件里硬编码的出厂默认序列号**，
> 官方升级器里的原始镜像同样存在，**不是某台机器的私有数据**，可以放心分发。

---

## 5. 救砖步骤（实机跑通）

1. **屏幕断电。**

2. **让芯片进强制烧录模式（BootROM 刷机态）**：

   按 **`hardware_boot_pins.jpg`** 的方向摆放板子，**短接 NOR 芯片的左上与右下两个引脚**，
   保持短接的同时插上 USB。

   ![短接位置](hardware_boot_pins.jpg)

   - 设备管理器出现 **`0416:9396`**（USB 大容量存储设备）就说明已经进了刷机态，此时可以松开短接。
   - 想省事：把这两个脚引线接一个小开关，闭合 = 强制刷机态，断开 = 正常运行，
     以后救砖不用再拿镊子去戳。

   > ⚠️ 短接前先对照实物确认引脚位置（不同批次板卡丝印与摆放朝向可能不同），
   > **不要短接 VCC 与 GND**。

3. 解压本包，运行 `TurboWriter V2.30.003_N329x1\TurboWriter.exe`。

4. 模式选 **SPI (Raw Data)** —— **按原样写文件，不加任何头**。

5. Image 选 `firmware\make_fix.bin`（589,824 B = 576 KB）。

6. 若提示设备掉线 → 点 **Reset Chip**，或重新插拔后再连。

7. 点 **Burn** → 出现 **`Burn successfully`**。

8. **断开短接**，重新上电 → 枚举回 **`1A2C:151D`**，屏幕亮。

全程约 5 分钟。**不需要 CH340 / 串口**。
接了串口的话，成功标志是 UART 打印 `SPI Booting Success`；失败时是 `SPI Booting Fail - Not For Boot`。

---

## 6. 烧录模式别选错

`make_fix.bin` 已经带好正确的启动头，**用 TurboWriter 的「SPI (Raw Data)」按原样烧即可**，
不要再让工具额外打包或加头。也不要拿官方升级器里的裸镜像、或其它来源的固件直接烧 ——
加载地址对不上就会表现为"不亮也不识别"，遇到这种情况重跑一遍第 5 节就能恢复。

---

## 7. 救砖之后

固件烧回后**开机动画是空的**（动画库区已被写过/清掉）。
重新烧一次动画即可：用官方软件，或本上位机的「开机动画 · 烧录进屏幕 Flash」。

- 官方软件对源 GIF 有 **约 9.5 MB** 的体积限制（素材库限制，**不是协议限制**）
- 动画库区在 NOR `0x400000`，约 6.75 MB，设备端只存 JPEG（GIF 在 PC 端转码）
- 系统固件区 `0x000000–0x090000`（576 KB）与 `make_fix.bin` **逐字节一致**，官方烧动画时不会改动它

---

## 8. 免责声明

- 刷写固件有风险，可能导致设备无法使用、失去保修。**请确认你理解每一步再动手。**
- 本工具包按「现状」提供，作者不对任何设备损坏或数据丢失负责。
- TurboWriter 及新唐 BSP 版权归 **Nuvoton** 所有（[OpenNuvoton](https://github.com/OpenNuvoton)），
  此处仅为分发便利而随包附带；`SPIFLASH ID.ini` 相对官方原版**只增加了一行** `A14018　　16384`。
- TCOMAS、LX800 为泰坦（tcomas.cn）的商标，本项目与之无关联，仅供学习交流。
